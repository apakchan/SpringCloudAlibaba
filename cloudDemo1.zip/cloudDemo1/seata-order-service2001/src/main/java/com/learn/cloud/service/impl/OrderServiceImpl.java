package com.learn.cloud.service.impl;

import com.learn.cloud.dao.OrderDao;
import com.learn.cloud.domain.Order;
import com.learn.cloud.service.AccountService;
import com.learn.cloud.service.OrderService;
import com.learn.cloud.service.StorageService;
import io.seata.spring.annotation.GlobalTransactional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
@Slf4j
public class OrderServiceImpl implements OrderService {
    @Resource
    private OrderDao orderDao;

    @Resource
    private StorageService storageService;

    @Resource
    private AccountService accountService;

    @Override
    @GlobalTransactional
    public void create(Order order) {
        log.info("--->开始新建订单");
        orderDao.create(order);
        log.info("--->开始新建订单成功");

        log.info("--->订单微服务开始调用库存，做扣减");
        storageService.decrease(order.getProductId(), order.getCount());
        log.info("--->订单微服务开始调用库存，做扣减，结束");

        log.info("--->订单微服务开始调用账户，扣余额");
        accountService.decrease(order.getUserId(), order.getMoney());
        log.info("--->订单微服务开始调用账户，扣余额,结束");

        log.info("--->订单微服务修改订单状态");
        orderDao.update(order.getUserId(), 0);
        log.info("--->订单微服务修改订单状态成功");

        log.info("--->订单下单结束");
    }
}
