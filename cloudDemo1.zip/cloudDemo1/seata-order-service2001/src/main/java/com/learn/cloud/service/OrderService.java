package com.learn.cloud.service;

import com.learn.cloud.domain.Order;

public interface OrderService {

    //新建订单
    void create(Order order);

    //修改订单状态

}
