package com.learn.cloud.lb;

import org.springframework.cloud.client.ServiceInstance;

import java.util.List;

public interface MyLoadBalance {

    //从机器容器中选择机器
    ServiceInstance instances(List<ServiceInstance> serviceInstances);

}
