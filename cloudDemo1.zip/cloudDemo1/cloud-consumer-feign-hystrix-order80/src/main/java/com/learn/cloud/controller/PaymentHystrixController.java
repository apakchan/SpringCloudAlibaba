package com.learn.cloud.controller;

import com.learn.cloud.service.PaymentHystrixService;
import com.netflix.hystrix.contrib.javanica.annotation.DefaultProperties;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

@Slf4j
@RestController
@DefaultProperties(defaultFallback = "paymentTimeOutFallbackMethod")
public class PaymentHystrixController {

    @Resource
    private PaymentHystrixService paymentHystrixService;

    @GetMapping("/consumer/payment/hystrix/ok/{id}")
    public String paymentInfo_OK(@PathVariable("id") Integer id){
        String res = paymentHystrixService.paymentInfo_OK(id);
        return res;
    }

    @GetMapping("/consumer/payment/hystrix/timeout/{id}")
//    @HystrixCommand(fallbackMethod = "paymentInfo_TimeOutHandler", commandProperties = {
//            @HystrixProperty(name="execution.isolation.thread.timeoutInMilliseconds",value="1500")
//    })
    @HystrixCommand
    public String paymentInfo_TimeOut(@PathVariable("id") Integer id){
        int i = 10 / 0;
        String res = paymentHystrixService.paymentInfo_TimeOut(id);
        return res;
    }

    public String paymentInfo_TimeOutHandler(Integer id){
        return "线程池: "  + Thread.currentThread().getName() + "  , paymentInfo_TimeOut, id:  " + id + "\t" + "┭┮﹏┭┮";
    }

    //全局fallback方法
    public String paymentTimeOutFallbackMethod(){
        return  "我是消费者80，对方支付系统繁忙，请10s后再试......┭┮﹏┭┮";
    }
}
