package com.learn.cloud.service;


public interface StorageService {
    void decrease(Long productId, Integer count);
}
