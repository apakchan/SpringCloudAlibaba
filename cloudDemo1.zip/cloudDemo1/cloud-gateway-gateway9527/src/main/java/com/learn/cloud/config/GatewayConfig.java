package com.learn.cloud.config;

import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class GatewayConfig {

    @Bean
    public RouteLocator customRouteLocator(RouteLocatorBuilder routeLocatorBuilder){
        RouteLocatorBuilder.Builder routes = routeLocatorBuilder.routes();
        //http://news.baidu.com/guonei
        RouteLocator path_route_cafebabe = routes.route("path_route_cafebabe",
                (x) -> x.path("/guonei")
                .uri("http://news.baidu.com/guonei")).build();  //访问 http://localhost:9527/guonei将会转发到 http://news.baidu.com/guonei
        return path_route_cafebabe;
    }
    @Bean
    public RouteLocator customRouteLocator2(RouteLocatorBuilder routeLocatorBuilder){
        RouteLocatorBuilder.Builder routes = routeLocatorBuilder.routes();
        //http://news.baidu.com/guonei
        RouteLocator path_route_cafebabe = routes.route("path_route_cafebabe2",
                (x) -> x.path("/guoji")
                        .uri("http://news.baidu.com/guoji")).build();  //访问 http://localhost:9527/guoji将会转发到 http://news.baidu.com/guoji
        return path_route_cafebabe;
    }
}
