package com.learn.cloud.service;


import com.learn.cloud.dao.AccountDao;

import javax.annotation.Resource;
import java.math.BigDecimal;

public interface AccountService {

    void decrease(Long userId, BigDecimal money);
}
