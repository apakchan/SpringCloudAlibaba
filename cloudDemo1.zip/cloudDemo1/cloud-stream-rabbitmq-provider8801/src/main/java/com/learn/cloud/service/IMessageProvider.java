package com.learn.cloud.service;

public interface IMessageProvider {
    public String send();

}
